<?php
   include "header.php";

if(isset($_GET['pid']))
$product_id = $_GET['pid'];
else
$product_id = 'all';

$products_data = get_all_products_data($product_id, $admin='no') ;
    //print_r($products_data);

?>

<!-- ------------------------------------------products_page_only------------------------------------------------------ -->

    <div id="products">
   		<div id="top_products"><?php echo $products_data['product_name'];


        ?>


   </div>

        <div id="content_products">
        <table  align="center" width="600px" id="table_of_products">
     <?
     if($products_data != false)
    {

                                                                                                                                                       // alt="'.$pval['img_description'].'"
					echo '<tr>';
					echo '<td width="150"><img width="200" src="products/'.$products_data['img_src'].'" title="'.$products_data['img_title'].'"  ></td>';
					echo '<td><p class="name">'.$products_data['product_name'].'</p><p class="description">'.$products_data['img_description'].'</p><p class="price">'.'$'.$products_data['product_price'].'</p>  <input type="submit" value="ADD TO CART" id="buy_it_button" class="buy_it_now_button" /> </td>';

					echo '</tr>';


     }
			?>
            </table>










        </div>
    </div>
    <!-- -----------------------------------------end of products_page_only-------------------------------------------------->


</div><!-- main content -->
<hr />
<div id="footer">
</div>
</div><!-- wrapper -->
</body>
</html>
