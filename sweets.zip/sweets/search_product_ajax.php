﻿<?php

include "connect_to_db.php";
include "functions.php";

$string = $_POST['my_string'];  // ????? Wafer1
$result = search($string);
//print_r($result);



if($result == false)
{
	die('אין תוצאות');
}
else
{
  	foreach($result as $searchkey=>$searchval)
  {
    //echo '<a href="#" class="res">'.$val['people_fname'].' '.$val['people_lname'].'</a>

	   	echo '<a href="products.php?cid='.$searchval['product_category_id'].'#p'.$searchval['product_id'].'" class="res">'.$searchval['product_name'].'</a><br />';

  }
}


?>

