﻿<?php

   include "header.php";


?>

<!-- ------------------------------------------about_us_only------------------------------------------------------ -->

    <div id="about_us">
   		<div id="top_about_us">ABOUT US
		</div>

        <div id="content_about_us">


     </div>
    </div>
    <!-- -----------------------------------------end of about_us_only-------------------------------------------------->


</div><!-- main content -->
<hr />
<div id="footer">
</div>
</div><!-- wrapper -->
</body>
</html>
