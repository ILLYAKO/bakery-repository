<?php
session_start();

   	$product_id = $_GET['pid'];
	$category_id = $_GET['cid'];


	if(isset($_SESSION['cart']))
	{
		if(array_key_exists( $product_id , $_SESSION['cart'] ) == true)
		{
		   	$_SESSION['cart'][$product_id]++;
			$_COOKIE['cart'][$product_id]++;
			header('location:products.php?cid='.$category_id);
			die();
		}

	}
	
	$_SESSION['cart'][$product_id] = 1;
	$_COOKIE['cart'][$product_id] = 1;
	header('location:products.php?cid='.$category_id);
	die();
		 

?>