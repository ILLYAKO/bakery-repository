﻿<?php
   include "header.php";
?>
<!-- ------------------------------------------contact_us_page_only------------------------------------------------------ -->
 <script type="text/javascreept">

       function form_validation()
{

    var formField = '';
    var justText = /^[a-zA-Z]+$/;
                                             //-----------------------------------------------
                                                         //firstName--------
    formField = document.getElementById('first_name');
	if ((formField.value.length <= 2) || (justText.test(formField.value) == false))

    {
      alert("error");
    } ;

                                            //-----------------------------------------------
                                                                  //lastName------------
	formField = document.getElementById('lastName');
	if ((formField.value.length <= 2) || (justText.test(formField.value) == false))
    {

        formField.className = 'errorTextbox';
		document.getElementById('errorLastName').innerHTML = 'error';
    }
    else
    {
        formField.className = 'validTextbox';
		document.getElementById('errorLastName').innerHTML = '';
    }

                                        //---------------------------------------
                                                    //e-mail
	var alphaExp = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

	formField = document.getElementById('eMail');
	if ((formField.value.length <= 5) || (alphaExp.test(formField.value) == false))
    {

        formField.className = 'errorTextbox';
		document.getElementById('errorEmail').innerHTML = 'error';
    }
    else
    {
        formField.className = 'validTextbox';
		document.getElementById('errorEmail').innerHTML = '';
    }




 </script>



    <div id="contact_us">
   		<div id="top_contact_us">CONTACT US
		</div>

        <div id="content_contact_us">
                    <fieldset>
                    <legend> CONTACT INFIRMATION </legend>
                    <form method="post" onsubmit="return(form_validation(this));">
        			     <table border="0" align="center" width="500px">
								<tr>
									<td><p>First Name:</p></td>
									<td><input type="text" class="forms" maxlength="50" name="name" id="first_name" /></td>
								</tr>
                                <tr>
									<td><p>Last Name:</p></td>
									<td><input type="text" class="forms" maxlength="50" name="name" /></td>
								</tr>
                                <tr>
									<td><p>Address:</p></td>
									<td><input type="text" class="forms" maxlength="100" name="name" /></td>
								</tr>
								<tr>
									<td><p>Email:</p></td>
									<td><input type="text" class="forms" maxlength="80" name="email" /></td>
								</tr>
                 <!--         </table>

                    </fieldset>
                <br/>
                <hr />
                <br/>
                    <fieldset>
                    <legend> YOUR COMMENT OR QUESTION </legend>

                            	<table border="0" align="center" width="500px">-->
            								<tr>
            									<td><p>Please enter your message hear:</p></td>
            									<td><textarea class="forms_text" name="message" rows="10" cols="25" wrap="physical"></textarea></td>
            								</tr>
            								<tr>
            									<td>&nbsp;</td>
            									<td style="padding-left:22px;"><input type="submit" style="" value="Send" name="submit" /></td>
            								</tr>

                                			<tr>
            									<th colspan="2">


            									</th>
            								</tr>

            					</table>
			    	</form>
                      </fieldset>

     </div>
    </div>  <!-- news_content -->
<!-- -----------------------------------------end of contact_us_page_only-------------------------------------------------->


</div><!-- main content -->
<hr />
<div id="footer">
</div>
</div><!-- wrapper -->
</body>
</html>
