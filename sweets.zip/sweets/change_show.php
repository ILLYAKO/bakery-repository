<?php
// set no caching


include "../../connect_to_db.php";
include "../../functions.php";

if(!isset($_POST['category_id'])|| !isset($_POST))
?>