<?php
session_start();
include "functions.php";
include "connect_to_db.php";



if(isset($_GET['p']))
$page_id = $_GET['p'];
else
$page_id = 1;


$page_data = get_page_data($page_id);
//$string = $_POST['my_string'];         //  for search       //?<?php cid='.$cval['cat_id'].'
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sweets</title>
 <link href="style.css" rel="stylesheet" type="text/css"  />
 <script type="text/javascript" src="jquery-1.7.2.min.js"></script>
 <script type="text/javascript">
 </script>
 <script type="text/javascript">
<!--

$(document).ready(function(){

$("#search_all").keyup(function(){

	var the_value_entered = $(this).val();

	if(the_value_entered == '')
	{
		$("#result").hide()
		return;
	}

	$.ajax({
		  //url: "search.php?rnd=" + Math.floor(Math.random()*1111111),
		  url: "search_product_ajax.php",
		  type: "POST",
		  data: "my_string=" + the_value_entered,
		  dataType: "html",
		  beforeSend: function(){
			    $("#loader").css({"visibility":"visible"});
		  },
		  success: function(my_msg){

				$("#result").show()
				$("#result").html(my_msg)
		  },
          error: function(){
				alert('Error');
		  },
		  complete: function(){
				$("#loader").css({"visibility":"hidden"});
		  },
		  timeout: 10000
	});

})


$(".res").live('click', function(event){
	//event.preventDefault();
	$("#result").hide()
	$("#number").val($(this).html())
})

// ////// del div with resalts
$("body").click(function(){
    $("#result").hide()

})//end del


})//END READY

//-->
</script>
<style>
#result
{
	position:    absolute;
	border:1px solid black;
	top:-1px;
	padding:2px;
	font-size:18px;
	font-family:arial;
	width:190px;
	margin:0 auto;
	height:auto;
	min-height:20px;
	display:none;
    background-color: white;
    z-index: 1000;
}
.search_ajax_box{
  position:  relative;
  margin:0 0 0 10px;
 }
.search_ajax_box a {
    font:15px  bolder Arial, Helvetica, sans-serif  ;
    color:gray;
    padding: 5px 8px;
 }


</style>
</head>


<body>
<div id="wrapper">
	<div id="header">  <!--  <?php echo mysql_error();?>  -->
    	<img src="images/logo.png" />
        <div id="block_ragistration">
        <a href="">Log in</a> or<br />
        <a href="">Register now</a>
        </div>
    </div>
 <div id="nav_menu_img">
         <div id="nav_menu">

         <ul class="nav_left dropdown">
            <?php

			$all_links = get_all_links();


			foreach($all_links as $lkey=>$lval)
			{
				echo '<li>';
                switch ($lval['pages_type']) {
                    case 'regular':
                        $go_to = 'page';
                        break;
                    case 'contact_us':
                        $go_to = 'contact_us';
                        break;
                    case 'products':
                        $go_to = 'products';
                        break;
                     case 'home':
                        $go_to = 'index';
                        break;
                    default:
                      $go_to = 'page';
                }


                echo '<a href="'.$go_to.'.php?p='.$lval['pages_id'].'">'.$lval['pages_link'].'</a>';

				//SECOND LEVEL
	   /*			if($lval['pages_type'] == 'products')
				{
					echo '<ul class="sub_menu">';

                  	$categories = get_all_categories(0);
					foreach($categories as $ckey=>$cval)
					{
                        $subs =  get_all_categories($cval['cat_id']);

                        echo '</li>';
                        if($subs != false)
                        {
                            echo '<li><a href="parent.php?cid='.$cval['cat_id'].'">'.$cval['cat_name'].'</a>';
                            echo '<ul>';
                            foreach($subs as $skey=>$sval)
                            {
                                 echo '<li><a href="products.php?cid='.$sval['cat_id'].'">'.$sval['cat_name'].'</a>';

                            }
                            echo '</ul>';

                        }
                        else
                        {
                           echo '<li><a href="products.php?cid='.$cval['cat_id'].'">'.$cval['cat_name'].'</a>';
                        }

					}

					echo '</ul>';
				}
					echo '</li>';
			}

        */
        	if($lval['pages_type'] == 'products')
				{
					echo '<ul class="sub_menu">';

                  	$categories = get_all_categories(0);
					foreach($categories as $ckey=>$cval)
					{
						echo '<li><a href="products.php?cid='.$cval['cat_id'].'">'.$cval['cat_name'].'</a>';
                        $subs =  get_all_categories($cval['cat_id']);
                        if($subs != false)
                        {
                            echo '<ul>';
                            foreach($subs as $skey=>$sval)
                            {
                                 echo '<li><a href="products.php?cid='.$sval['cat_id'].'">'.$sval['cat_name'].'</a>';

                            }
                            echo '</ul>';

                        }
                        echo '</li>';
					}

					echo '</ul>';
				}
					echo '</li>';
			}
			?>

        </ul>
        <ul class="nav_right">
            <li><a href="page.php?pid=15"> YOUR CART</a></li>

        </ul>
       </div>
    </div>
<div id="main_content">
<div id="right_content">

    <div id="search_block">
    	<div id="top_search" >I AM LOOKING FOR</div>
          <form action="form_action.asp" method="post"  >
               <input type="text" name="search_all" id="search_all" /><br />
               <div class="search_ajax_box"><div id="result" ></div></div><br />     <!--     onclick="this.value='';"    -->
                                               <!--  <select name="search_by_category" id="search_by_category">
                                                    <option value="selectCategory" selected="selected" readonly="readonly" disabled="disabled">SELECT CATEGORY</option>
                                                    <option id="1">All categories</option>  -->
                                                   <?
                                                //   	$categories = get_all_categories(0);
                                  				//	foreach($categories as $ckey=>$cval)
                                  					{
                                  				//		echo '<option value="'.$cval['cat_id'].'">'.$cval['cat_name'].'</option>';
                                  					}
                                  				  ?>
                                                    <!--<option>Cakes</option>
                                                    <option>Chocolate</option>
                                                    <option>Biscuits</option>
                                                    <option>Croissants</option>
                                                    <option>Wafers</option>-->

                                                 <!-- </select>  -->
               <input type="submit" value="SEARCH" id="search_button" />
          </form>
    </div>

    <div id="order_block">
    <div id="top_order">YOUR ORDER</div>
        <div id="text_order">
        <table>
        <?php
            if(isset($_SESSION['cart']) && $_SESSION['cart'] != '' )
        	{
        		echo '<tr><th>Pic</th><th>Name</th><th>Quantity</th></tr>';
        		foreach($_SESSION['cart'] as $key=>$val)
        		{
                    $product_data = get_all_products_data($key);

                    echo '<tr>';
        			echo '<td><IMG  SRC="products/'.$product_data['img_src'].'" WIDTH="30" BORDER="0" ALT=""></td>';
        			echo '<td>'.$product_data['product_name'].'</td>';
        			echo '<td>'.$val.'</td>';
        			//echo '<td>';
        			//echo '<a href="update_cart.php?action=m&pid='.$key.'">More</a><br />';
        			//echo '<a href="update_cart.php?action=l&pid='.$key.'">Less</a><br />';
        			//echo '<a href="update_cart.php?action=d&pid='.$key.'">Del</a></td>';
        			echo '</tr>';
        		}
        		echo '<tr><td colspan="5"><a href="page.php?p=15"><center>See Your Cart</center></a></td></tr>';
        	}
        	else
        		{
        			echo '<tr><td>Your Cart is Empty</td></tr>';
        		}
        ?>
        </table>
        </div>
    </div>

</div>
<!-- ------------------------------------------header------------------------------------------------------ -->