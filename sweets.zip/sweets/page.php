﻿<?php
    include "header.php";
?>

<!-- ------------------------------------------YOUR CARD_only------------------------------------------------------ -->

    <div id="about_us">
   		<div id="top_about_us">YOUR CARD
		</div>

        <div id="content_about_us">

             <table>
        <?php
            if(isset($_SESSION['cart']) && $_SESSION['cart'] != '' )
        	{
        		echo '<tr><th>Pic</th><th>Name</th><th>Quantity</th><th>Update</th></tr>';
        		foreach($_SESSION['cart'] as $key=>$val)
        		{
                    $product_data = get_all_products_data($key);

                    echo '<tr>';
        			echo '<td><IMG  SRC="products/'.$product_data['img_src'].'" WIDTH="30" BORDER="0" ALT=""></td>';
        			echo '<td>'.$product_data['product_name'].'</td>';
        			echo '<td>'.$val.'</td>';
        			echo '<td>';
        			echo '<a href="update_cart.php?action=m&pid='.$key.'">More</a><br />';
        			echo '<a href="update_cart.php?action=l&pid='.$key.'">Less</a><br />';
        			echo '<a href="update_cart.php?action=d&pid='.$key.'">Del</a></td>';
        			echo '</tr>';
        		}
        		//echo '<tr><td colspan="5"><a href="page.php?p=15"><center>See Your Cart</center></a></td></tr>';
        	}
        	else
        		{
        			echo '<tr><td>Your Cart is Empty</td></tr>';
        		}
        ?>
        </table>
     </div>
    </div>
    <!-- -----------------------------------------end of contact_us_page_only-------------------------------------------------->


</div><!-- main content -->
<hr />
<div id="footer">
</div>
</div><!-- wrapper -->
</body>
</html>
