<?php

include "../connect_to_db.php";
include "../functions.php";

if(isset($_GET['p']))
$page_id = $_GET['p'];
else
header('location: index.php');

$page_data = get_page_data($page_id);

//echo '<pre>';print_r($page_data);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Edit Page: <?=$page_data['pages_header'];?> </title>
<meta name="generator" content="editplus" />
<meta name="author" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<style>
*
{
	font-family:arial;
}

textarea
{
	width:250px;
	height:100px;
}

table
{
	border-collapse:collapse;
}

td
{
	border:1px solid #555;
	vertical-align:top;
	padding:5px;
}

</style>
</head>

<body>
<h3>Edit The Page: <font size="" color="red"><?=$page_data['pages_header'];?></font></h3>
<form method="post" action="do_the_update.php">
<input type="hidden" name="fld_page_id" value="<?=$page_id;?>" />
<table border="0" cellspacing="0">
		<tr>
			<td>Header</td>
			<td><input type="text" name="fld_page_header" value="<?=$page_data['pages_header'];?>" /></td>
		</tr>
		<tr>
			<td>Content</td>
			<td><textarea name="fld_page_content"><?=$page_data['pages_text'];?></textarea></td>
		</tr>
		<tr>
			<td>Link</td>
			<td><input type="text" name="fld_page_link" value="<?=$page_data['pages_link'];?>" /></td>
		</tr>
		<tr>
			<td>Order</td>
			<td><input type="text" name="fld_page_order" value="<?=$page_data['pages_order'];?>" /></td>
		</tr>
		<tr>
			<td>Show?</td>
			<td>
				<input type="radio" name="fld_page_show" value="yes" <?php if($page_data['pages_show']=='yes'){echo ' checked="checked" ';}?>> Yes<br />
				<input type="radio" name="fld_page_show" value="no" <?php if($page_data['pages_show']=='no'){echo ' checked="checked" ';}?>> No<br />
			</td>
		</tr>
	  <!--	<tr>
			<td>Frame</td>
			<td>
				<input type="checkbox" name="fld_page_frame" value="yes" <?if($page_data['pages_frame']=='yes'){echo ' checked="checked" ';}?>> Yes<br />
			</td>
		</tr>-->
		<tr>
			<td>Page Type</td>
			<td>
					<select name="fld_page_type">
						<option value="" <?if($page_data['pages_type']==''){echo ' selected="selected" ';}?>>Please Choose</option>
						<option value="regular" <?php if($page_data['pages_type']=='regular'){echo ' selected="selected" ';}?>>Regular</option>
						<option value="gallery" <?php if($page_data['pages_type']=='gallery'){echo ' selected="selected" ';}?>>Gallery</option>
						<option value="contact" <?php if($page_data['pages_type']=='contact'){echo ' selected="selected" ';}?>>Contact</option>
                        	<option value="home" <?php if($page_data['pages_type']=='home'){echo ' selected="selected" ';}?>>Home</option>
                            <option value="products" <?php if($page_data['pages_type']=='products'){echo ' selected="selected" ';}?>>Products</option>
					</select>
			</td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" value="UPDATE" /></td>
		</tr>
		
	</table>	

</form>
</body>
</html>