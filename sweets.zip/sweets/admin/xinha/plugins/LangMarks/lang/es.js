// I18N constants
// LANG: "es", ENCODING: UTF-8
// translated: Derick Leony <dleony@gmail.com>
{
  "language select": "seleccionar idioma",
  "&mdash; language &mdash;":	"&mdash; idioma &mdash;",
  "Greek": "Griego",
  "English": "Inglés",
  "French": "Francés",
  "Latin": "Latín"
};
