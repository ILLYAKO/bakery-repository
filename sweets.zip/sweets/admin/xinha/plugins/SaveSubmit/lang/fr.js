// I18N constants
// LANG: "fr", ENCODING: UTF-8
{ 
	"Save": "Enregistrer",
	"Saving...": "Enregistrement...",
	"in progress": "en cours",
	"Ready": "Prêt"
};