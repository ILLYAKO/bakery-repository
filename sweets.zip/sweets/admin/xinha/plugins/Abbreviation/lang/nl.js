// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{
  "Abbreviation": "Afkorting",
  "Expansion:": "Uitbreiding:",
  "Delete": "Verwijderen"
};
