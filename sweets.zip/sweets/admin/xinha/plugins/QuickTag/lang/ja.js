// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Quick Tag Editor": "クイックタグエディタ",
  "Enter the TAG you want to insert": "挿入したいタグを入力",
  "You have to select some text": "テキストを選択しなければなりません",
  "There are some unclosed quote": "閉じていない引用符があります",
  "This attribute already exists in the TAG": "タグにはすでに同じ属性があります",
  "No CSS class avaiable": "CSSクラスがありません",
  "OPTIONS": "選択肢",
  "ATTRIBUTES": "属性",
  "TAGs": "タグ",
  "Colors": "色",
  "Ok": "OK",
  "Cancel": "中止"
};