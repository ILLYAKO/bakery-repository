[
  { title: 'Grin',      src: 'Grin.gif'      },
  { title: 'Angry',     src: 'Angry.gif'     },
  { title: 'Excited',   src: 'Excited.gif'   },
  { title: 'Cool',      src: 'Cool.gif'      },
  { title: 'Wink',      src: 'Wink.gif'      },
  { title: 'Surprised', src: 'Surprised.gif' },
  { title: 'Sad',       src: 'Sad.gif'       },
  { title: 'Pleased',   src: 'Pleased.gif'   }
]