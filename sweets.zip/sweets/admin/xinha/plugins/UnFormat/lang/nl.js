// I18N constants
// LANG: "nl", ENCODING: UTF-8
{
  "Page Cleaner": "Pagina Schoonmaker",
  "Cleaning Area": "Schoonmaak gebied",
  "Selection": "Geselecteerde tekst",
  "All": "Alles",
  "Cleaning options": "Schoonmaak opties",
  "Formatting:": "Format",
  "All HTML:": "Alle html",
  "Select which types of formatting you would like to remove." : "Selecteer welke types van Formatteren je wilt verwijderen"
};
