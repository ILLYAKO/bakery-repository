<?php

include "../connect_to_db.php";
include "../functions.php";

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Admin </title>
<meta name="generator" content="editplus" />
<meta name="author" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<style>

a
{
  color:blue;
  line-height: 20px;
}

a.new
{
	color:red;
}

</style>

<script type="text/javascript">
<!--

function confirm_delete_page(pages_id)
{
	var answer = confirm(' \n Are you sure want to delete\n \n this page?');
	if(answer == true)
	{
		location.href = 'delete_page.php?p=' + pages_id;
	}
}

function confirm_delete_category(cat_id)
{
	var answer = confirm(' \n Are you sure want to delete\n \n this category?');
	if(answer == true)
	{
		location.href = 'categories/delete_category.php?p=' + cat_id;
	}
}



//-->
</script>
</head>

<body style="background:#560000;">

<table>
  <tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
<div style="width:700px; height:auto; margin:30px auto;">
  <div style=" background-image: url(../images/logo.png); background-position: right top; background-repeat: no-repeat; background-size:25%;">
   <h3 style="color:white; 	font:18px  bolder Arial, Helvetica, sans-serif; ">WELCOME  to Your CMS</h3>
      <!--  <a href="../index.php"><img src="../images/logo.png" width="250" alt="homepage" /></a>    -->
         <br/>
  </div>


  <div class="" style="width:700px; height:auto; background: #E7E7E7; margin:0 auto; overflow:auto;  border: solid 3px #3E0000; border-radius: 10px;

-webkit-box-shadow: 0px 0px 2px 3px rgba(255, 255, 255, 0.7);
 box-shadow: 0px 0px 3px 2px rgba(255, 255, 255, 0.7);">
  <div style="width:700px; height:14px;   background-image: url(../images/top_admin.png); background-size:5%;"></div>
  <div class="content" style="padding:15px 30px;">
          <h3>Please Choose a Page:</h3>
          <table border="1" cellpadding="3" cellspacing="3">
             <tr><th>NAME OF PAGE</th><th>DELETE</th></tr>
          <?php

          	$all_links = get_all_links_for_admin();


          	foreach($all_links as $lkey=>$lval)
          	{
          		if($lval['pages_show'] == 'yes')

                 // echo '<a href="javascript:confirm_delete('.$lval['pages_id'].')">X</a>     &nbsp;&nbsp;&nbsp;&nbsp;';
                 // echo '<li><a href="delete_page.php?p='.$lval['pages_id'].'">X</a> - <a href="edit_pages.php?p='.$lval['pages_id'].'">'.$lval['pages_link'].'&nbsp;</a></li>';

          		echo '<tr> <td> <a href="edit_pages.php?p='.$lval['pages_id'].'">'.$lval['pages_link'].'&nbsp;</a></td>
                      <td><a href="javascript:confirm_delete_page('.$lval['pages_id'].')" style="color:red; text-decoration: none;"><b>X</b></a></td></tr>';
          		else
          		echo '<tr><td><a  style="color:gray" href="edit_pages.php?p='.$lval['pages_id'].'">'.$lval['pages_link'].'&nbsp;</a></td>
                      <td><a  href="javascript:confirm_delete_page('.$lval['pages_id'].')"  style="color:red; text-decoration: none;"><b>X</b></a></td></tr>';

          	}


          ?>
          <td><a class="new" href="add_new_page.php">Add New Page</a></td>

          </table>
          <hr />
          <h3>Please Choose the Category for Edit the Product</h3>
            <?php
              echo '<tr class="sub_menu">';

                            $categories = get_all_categories(0);
          					foreach($categories as $ckey=>$cval)
          					{

          			            $subs =  get_all_categories($cval['cat_id']);


                                  if($subs != false)
                                  {
                                      echo '<td>
                                      <a  href="javascript:confirm_delete_category('.$cval['cat_id'].')"  style="color:red; text-decoration: none;"><b>X</b></a>
                                      <a href="products/show_products_parent.php?cid='.$cval['cat_id'].'">'.$cval['cat_name'].'</a>';


                                      echo '<tr>';
                                      foreach($subs as $skey=>$sval)
                                      {
                                           echo '<td><a  href="javascript:confirm_delete_category('.$cval['cat_id'].')"  style="color:red; text-decoration: none;"><b>X</b></a>
                                           <a href="products/show_products.php?cid='.$sval['cat_id'].'">'.$sval['cat_name'].'</a>';


                                      }
                                   echo '<td><a class="new" href="categories/add_new_category.php?parent='.$cval['cat_id'].'">Add New Category</a></td> ' ;
                                   echo '</tr>';

                                  }
                                  else
                                 {
                                    echo '<td>   <a  href="javascript:confirm_delete_category('.$cval['cat_id'].')"  style="color:red; text-decoration: none;"><b>X</b></a>
                                                <a href="products/show_products.php?cid='.$cval['cat_id'].'">'.$cval['cat_name'].'</a>';
                                    echo '<tr><td><a class="new" href="categories/add_new_category.php?parent='.$cval['cat_id'].'">Add New Category</a></td></tr>' ;
                                 }

                              //    echo '<td><a href="show_products.php?cid='.$cval['cat_id'].'">'.$cval['cat_name'].'</a>';

                                  echo '</td>';
          					}
                                 echo'<td ><a class="new" href="categories/add_new_category.php?parent=0">Add New Category</a></td> ' ;
          					echo '</tr>';




            ?>
  </div>  <!-- end content -->
  <div style="width:700px; height:14px;   background-image: url(../images/bottom_admin.png); background-size:5%; "></div>
  </div>
</div>
<hr />
to delete
  <br />    <br />
<a href="upload_product/upload_product.php">Upload Products</a><br />
<a href="show_products.php">Edit Products</a><br />
<a href="upload_image/upload_image.php">Edit Gallery</a><br /> <br />  <br />



<a href="products/cakes.php">CAKES</a><br />
<a href="products/chocolate.php">CHOCOLATE</a><br />
<a href="products/edit_product.php">edit_product.php</a><br /> <br /> <br />
</body>
</html>
