<?php

include "../../connect_to_db.php";
include "../../functions.php";


$cat_id = $_POST['fld_cat_id'];
$cat_name = str_replace("'", "&#39", $_POST['cat_name']);   //   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
$cat_order = $_POST['fld_cat_order'];
$categories_show = $_POST['fld_categories_show'];




$result = update_category($cat_id, $cat_name, $categories_show, $cat_order) ; 

if($result == false)
echo 'Something is Wrong!!';
else
{

	header('location: ../products/show_products.php?cid='.$cat_id.'');

}


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> new document </title>
<meta name="generator" content="editplus" />
<meta name="author" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />


</head>

<body >
<?php

if($result == false)
echo '<font size="" color="red">Problem Updating The category</font>';
else
echo '<font size="" color="green">Update was Successful!</font>';

?>
<br /><br />
<!--Please wait 5 seconds.<br />
<a href="edit_products.php?p=<?=$product_id;?>">Back to Page</a><br />
<a href="index.php">Back to Home</a>
 -->
</body>
</html>