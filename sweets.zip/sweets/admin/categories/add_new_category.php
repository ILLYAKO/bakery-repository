<?php
include "../../connect_to_db.php";
include "../../functions.php";

if(isset($_GET['parent']))
$parent = $_GET['parent'];
else
header('location: index.php');

$result = add_new_category($parent);

if($result == false)
die('You have a problem adding new category!');
else
header('location:../index.php');



?>