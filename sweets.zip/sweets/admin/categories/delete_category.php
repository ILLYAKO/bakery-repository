<?php
include "../../connect_to_db.php";
include "../../functions.php";


if(isset($_GET['cid']))
$cat_id = $_GET['cid'];
else
header('location: ../index.php');




$result = delete_category($cat_id);


if($result == false)
die('You have a problem DELETING the category!');
else
header('location:../index.php');





?>