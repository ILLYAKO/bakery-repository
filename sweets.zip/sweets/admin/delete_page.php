<?php
include "../connect_to_db.php";
include "../functions.php";

if(isset($_GET['p']))
$page_id = $_GET['p'];
else
header('location: index.php');

$result = delete_page($page_id);

if($result == false)
die('You have a problem DELETING the page!');
else
header('location:index.php');





?>